/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cafemanagmentsystem;

/**
 * @author ( Andrew Moheb - Mahmoud Wael - Ahmed Einshoka - Ibrahim Mohamed - Abdelrahman Salah )
 */
public class Cafemanagmentsystem {


    public static void main(String[] args) {
       
    }
    
}
